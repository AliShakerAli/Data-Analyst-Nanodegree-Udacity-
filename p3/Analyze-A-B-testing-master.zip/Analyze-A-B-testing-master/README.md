# Analyze A/B Results

## Description

A/B tests are very commonly performed by data analysts and data scientists. It is important that I get some practice working with the 
difficulties of these For this project, this is an A/B test run by an e-commerce website. 
my goal was to work through this notebook to help the company understand if they should implement the new page, keep the old page, 
or perhaps run the experiment longer to make their decision.

## Dependancies

this project is created using Jupyter Notebook:
* python 3
* Pandas
* numpy
* matplotlib 

## Part I - Probability
## Part II - A/B Test
## Part III - Regression

