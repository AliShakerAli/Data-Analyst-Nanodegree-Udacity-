# ProsperLoan Data Exploration

## Dataset

This informational collection contains 113,937 advances with 81 factors on each advance, including credit sum, borrower rate (or financing cost), current advance status, borrower salary, and numerous others. This information word reference clarifies the factors in the informational collection. The task objective isn't relied upon to investigate the entirety of the factors in the dataset! Be that as it may, center around just investigation on around 10-15 of them.


## Summary of Findings

LoanStatus of all Borrowers are with current and finished state •EmploymentStatus of all Borrowers are with Employed State •Majority of the advance candidates are from 50K to 75K territory with emloyeed status •The conveyance of month to month pay of candidates is a privilege slanted in light of the fact that there will be hardly any candidates with significant compensation. •Applicants with incomerange of 50K to 75K territory have their succeed rating falling under AA, A, B and C •LoanStatus with current and finished have own homes when they applied for advances •The month to month pay of borrowers are having higher qualities for utilized, other and all day work status with the thrive rating of AA, An and B •We see that without property holder will in general have a higher loan fee, and subsequently lower rating.However mortgage holder will in general have lower financing cost and higher rating. So we can securely say that property holder is most secure wagered while gving a credit. We can likewise obviously see that HR flourish rating candidates have higher loan fees

## Key Insights for Presentation

For the introduction, I zeroed in basically with the highlights that are significant for endorsement of loanstatus I start by taking a gander at the distrbuiton of every single numeric and downright factors and did all the essential univariate, bivariate and mulitvariate examination on the chose varaibles.

The major insights obtained are :

•LoanStatus of all Borrowers are with current and finished state •EmploymentStatus of all Borrowers are with Employed State •Top IncomeRange of all Borrowers are inside $50,000-74,999 •Majority of the borrowers are with a control of Professional and Executive

•Majority of the borrowers are with a rating or score from 4 to 8 •The borrowers rate follow a roughly unimodal dispersion, with the top around 0.16. •The beginning measure of the credit is fascinating. Here we see that the conveyance is a privilege slanted with numerous pinnacles saw at 4000 USD, 10000 USD and 15000 USD. •Loan unique sum and month to month advance installment is exceptionally associated and it is normal and borrowers financing cost and legitimate score are profoundly related(- vely), Borrower loan fee and loanamount are - vely connected.

To finish up this examination , I state that the credit endorsement status is vigorously subject to the candidate's data on IncomeRange, Homeownerstatus and business status.

